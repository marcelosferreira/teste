/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.petrobras.sigiop;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author RNS7
 */
public class SigiopLiberacaoExport {

    /**
     * @param args the command line arguments
     */
    public void exportar(String[] listaRt, String path) throws SQLException, IOException
    {

        String oracleURLSigiop = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=sand-scan1.petrobras.com.br)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=exaprd01.petrobras.com.br)))";

        SimpleDateFormat dataHoraFormato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        List<String> rts = new ArrayList<String>();
        
        String sqlSigiop = "SELECT B.RTSI_CD_RTSUBITEM "
            + "    , C.RTCA_CD_QMNUM "
            + "    , C.RTIT_NR_ITEM "
            + "    , B.RTSI_NR_SUBITEM "
            + "    , B.RTSI_IN_CODTRA"
            + "    , B.RTSI_DT_LIBERACAO_INICIAL "
            + "    , B.RTSI_DT_LIBERACAO "
            + " FROM SIGIOP.RT_SUBITEM B "
            + " INNER JOIN SIGIOP.RT_ITEM C ON C.RTIT_CD_RTITEM = B.RTIT_CD_RTITEM "
            + " WHERE B.RTSI_IN_CODTRA IN ('M','T') AND C.RTCA_CD_QMNUM IN (:1) "
            + " AND B.RTSI_DT_LIBERACAO_INICIAL IS NOT NULL";

        File arquivo = new File(path);

        try( FileWriter fw = new FileWriter(arquivo) ){

            fw.append("RT");
            fw.append('\t');
            fw.append("ITEM");
            fw.append('\t');
            fw.append("SUBITEM");
            fw.append('\t');
            fw.append("MODAL");
            fw.append('\t');
            fw.append("DATA LIBERACAO INICIAL");
            fw.append('\t');
            fw.append("DATA LIBERACAO");
            fw.append('\n');

            for (int i = 0;i<listaRt.length; i++){

                rts.add(listaRt[i]);

                if (rts.size() == 900 || i == listaRt.length - 1){

                    try (Connection cnnSigiop = DriverManager.getConnection(
                        oracleURLSigiop, "SIGIOP_SPOTFIRE", "Ju5$oDF375fa")) {

                        Statement stSigiop = cnnSigiop.createStatement();

                        ResultSet resultSigiop = stSigiop.executeQuery(sqlSigiop.replace(":1", rts.toString().replace("[", "").replace("]", "")));

                        while (resultSigiop.next()) {

                            fw.append(resultSigiop.getString("RTCA_CD_QMNUM"));
                            fw.append('\t');
                            fw.append(resultSigiop.getString("RTIT_NR_ITEM"));
                            fw.append('\t');
                            fw.append(resultSigiop.getString("RTSI_NR_SUBITEM"));
                            fw.append('\t');
                            fw.append(resultSigiop.getString("RTSI_IN_CODTRA"));
                            fw.append('\t');

                            if (resultSigiop.getDate("RTSI_DT_LIBERACAO_INICIAL") != null)
                                fw.append(dataHoraFormato.format(resultSigiop.getDate("RTSI_DT_LIBERACAO_INICIAL")));

                            fw.append('\t');

                            if (resultSigiop.getDate("RTSI_DT_LIBERACAO") != null)
                                fw.append(dataHoraFormato.format(resultSigiop.getDate("RTSI_DT_LIBERACAO")));

                            fw.append('\n');

                        }

                        fw.flush();

                    }
                    catch(IOException ex){
                        throw ex;
                    }

                    rts = new ArrayList<String>();

                }
                
            }

            fw.close();
        } 
        catch(IOException ex){
            throw ex;
        }


    }

    
}
