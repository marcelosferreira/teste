/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.petrobras.sigiop;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author RNS7
 */
public class SigiopProgramacaoExport {

    /**
     * @param args the command line arguments
     */
    public void exportar(String[] listaRt, String path) throws SQLException, IOException
    {

        String oracleURLSigiop = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=sand-scan1.petrobras.com.br)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=exaprd01.petrobras.com.br)))";

        SimpleDateFormat dataHoraFormato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        List<String> rts = new ArrayList<String>();
        
        String sqlSigiop = "SELECT B.RTSI_CD_RTSUBITEM "
            + "    , C.RTCA_CD_QMNUM "
            + "    , C.RTIT_NR_ITEM "
            + "    , B.RTSI_NR_SUBITEM "
            + "    , A.RTAT_CD_QMNUM "
            + "    , A.RANKING "
            + "    , A.RTAI_DT_CRIACAO"
            + "    , A.RTAT_DT_INIPREVAT"
            + " FROM SIGIOP.RT_SUBITEM B "
            + "  INNER JOIN SIGIOP.RT_ITEM C ON C.RTIT_CD_RTITEM = B.RTIT_CD_RTITEM "
            + "  INNER JOIN (SELECT DISTINCT Z.RTSI_CD_RTSUBITEM "
            + "                    , X.RTAT_CD_QMNUM "
            + "                    , Z.RTAI_DT_CRIACAO "
            + "                    , X.RTAT_DT_INIPREVAT "
            + "                    , RANK() OVER (PARTITION BY Z.RTSI_CD_RTSUBITEM ORDER BY Z.RTAI_DT_MODIFICACAO) RANKING "
            + "                FROM SIGIOP.RT_ATENDIMENTO_ITEM Z "
            + "                    INNER JOIN SIGIOP.RT_ATENDIMENTO X ON Z.RTAT_CD_QMNUM = X.RTAT_CD_QMNUM "
            + "                ORDER BY Z.RTSI_CD_RTSUBITEM) A ON A.RTSI_CD_RTSUBITEM = B.RTSI_CD_RTSUBITEM "
            + "WHERE B.RTSI_IN_CODTRA = 'M' AND C.RTCA_CD_QMNUM IN (:1)";

        //System.getProperty("user.home") + "\\Desktop";

        File arquivo = new File(path);

        try( FileWriter fw = new FileWriter(arquivo) ){ //2

            fw.append("RT");
            fw.append('\t');
            fw.append("ITEM");
            fw.append('\t');
            fw.append("SUBITEM");
            fw.append('\t');
            fw.append("ATENDIMENTO");
            fw.append('\t');
            fw.append("ORDEM");
            fw.append('\t');
            fw.append("DATA PROGRAMACAO");
            fw.append('\t');
            fw.append("DATA CRONOGRAMA");
            fw.append('\n');

            for (int i = 0;i<listaRt.length; i++){

                rts.add(listaRt[i]);

                if (rts.size() == 900 || i == listaRt.length - 1){

                    try (Connection cnnSigiop = DriverManager.getConnection(
                        oracleURLSigiop, "SIGIOP_SPOTFIRE", "Ju5$oDF375fa")) {

                        Statement stSigiop = cnnSigiop.createStatement();

                        ResultSet resultSigiop = stSigiop.executeQuery(sqlSigiop.replace(":1", rts.toString().replace("[", "").replace("]", "")));

                        while (resultSigiop.next()) {

                            fw.append(resultSigiop.getString("RTCA_CD_QMNUM"));
                            fw.append('\t');
                            fw.append(resultSigiop.getString("RTIT_NR_ITEM"));
                            fw.append('\t');
                            fw.append(resultSigiop.getString("RTSI_NR_SUBITEM"));
                            fw.append('\t');
                            fw.append(resultSigiop.getString("RTAT_CD_QMNUM"));
                            fw.append('\t');
                            fw.append(resultSigiop.getString("RANKING"));
                            fw.append('\t');

                            if (resultSigiop.getDate("RTAI_DT_CRIACAO") != null)
                                fw.append(dataHoraFormato.format(resultSigiop.getDate("RTAI_DT_CRIACAO")));

                            fw.append('\t');

                            if (resultSigiop.getDate("RTAT_DT_INIPREVAT") != null)
                                fw.append(dataHoraFormato.format(resultSigiop.getDate("RTAT_DT_INIPREVAT")));

                            fw.append('\n');

                        }

                        fw.flush();

                    }
                    catch(IOException ex){
                        throw ex;
                    }

                    rts = new ArrayList<String>();

                }
                
            }

            fw.close();
        } 
        catch(IOException ex){
            throw ex;
        }


    }

    
}
