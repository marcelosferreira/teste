﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class ASO
    {
        public int Id { get; set; }
        public String Descricao { get; set; }
        public int IdFuncionario { get; set; }
        public int IdEmpresa { get; set; }
        public String Caminho { get; set; }
        public DateTime DataASO { get; set; }

        public List<ASO> ListarASOs(int idFuncionario)
        {
            var lista = new List<ASO>();
            var asoDb = new Database.ASO();
            foreach (DataRow row in asoDb.ListarPorFuncionario(idFuncionario).Rows)
            {
                var aso = new ASO();
                aso.Id = Convert.ToInt32(row["IdASO"]);
                aso.Descricao = row["Descricao"].ToString();
                aso.IdFuncionario = Convert.ToInt32(row["IdFuncionario"]);
                aso.IdEmpresa = Convert.ToInt32(row["IdEmpresa"]);
                aso.Caminho = row["Caminho"].ToString();
                aso.DataASO = Convert.ToDateTime(row["DataASO"]);

                lista.Add(aso);
            }

            return lista;
        }

        public void SalvarAso()
        {
            new Database.ASO().SalvarAso(this.Descricao, this.Caminho, this.DataASO, this.IdEmpresa, this.IdFuncionario);
        }
    }
}
