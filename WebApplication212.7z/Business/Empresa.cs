﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Empresa : IUsuario
    {
        public int Id { get; set; }
        public String Nome { get; set; }
        public String Email { get; set; }
        public String Senha { get; set; }
        public DateTime DataCadastro { get; set; }

        public List<Empresa> Listar()
        {
            var lista = new List<Empresa>();
            var empresaDb = new Database.Empresa();
            foreach (DataRow row in empresaDb.Listar().Rows)
            {
                var empresa = new Empresa();
                empresa.Id = Convert.ToInt32(row["IdEmpresa"]);
                empresa.Nome = row["Nome"].ToString();
                empresa.Email = row["Email"].ToString();
                empresa.Senha = row["Senha"].ToString();
                empresa.DataCadastro = Convert.ToDateTime(row["DataCadastro"]);

                lista.Add(empresa);
            }

            return lista;
        }
    }
}
