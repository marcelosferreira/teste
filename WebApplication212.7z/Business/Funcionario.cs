﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Funcionario : IUsuario
    {
        public int Id { get; set; }
        public String Nome { get; set; }
        public String Email { get; set; }
        public String Senha { get; set; }
        public DateTime DataCadastro { get; set; }

        public List<Funcionario> Listar()
        {
            var lista = new List<Funcionario>();
            var funcionarioDb = new Database.Funcionario();
            foreach (DataRow row in funcionarioDb.Listar().Rows)
            {
                var funcionario = new Funcionario();
                funcionario.Id = Convert.ToInt32(row["IdFuncionario"]);
                funcionario.Nome = row["Nome"].ToString();
                funcionario.Email = row["Email"].ToString();
                funcionario.Senha = row["Senha"].ToString();
                funcionario.DataCadastro = Convert.ToDateTime(row["DataCadastro"]);

                lista.Add(funcionario);
            }

            return lista;
        }

        public List<Funcionario> Listar(int id)
        {
            var lista = new List<Funcionario>();
            var funcionarioDb = new Database.Funcionario();
            foreach (DataRow row in funcionarioDb.Listar(id).Rows)
            {
                var funcionario = new Funcionario();
                funcionario.Id = Convert.ToInt32(row["IdFuncionario"]);
                funcionario.Nome = row["Nome"].ToString();
                funcionario.Email = row["Email"].ToString();
                funcionario.Senha = row["Senha"].ToString();
                funcionario.DataCadastro = Convert.ToDateTime(row["DataCadastro"]);

                lista.Add(funcionario);
            }

            return lista;
        }

        public static void DeletarFuncionario(int idFuncionario)
        {
            new Database.Funcionario().DeletarFuncionario(idFuncionario);
        }
    }
}
