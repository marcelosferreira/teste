﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class Empresa
    {
        private string SqlConn()
        {
            return ConfigurationManager.AppSettings["SqlConnection"];
        }

        public DataTable Listar()
        {
            using (SqlConnection connection = new SqlConnection(SqlConn()))
            {
                string queryString = "SELECT * FROM [dbo].[Empresas]";
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();

                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;

                DataTable table = new DataTable();
                adapter.Fill(table);
                return table;

            }
        }
    }
}
