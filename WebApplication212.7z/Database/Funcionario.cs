﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class Funcionario
    {
        private string SqlConn()
        {
            return ConfigurationManager.AppSettings["SqlConnection"];
        }

        public DataTable Listar()
        {
            using (SqlConnection connection = new SqlConnection(SqlConn()))
            {
                string queryString = "select * from funcionarios";
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();

                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;

                DataTable table = new DataTable();
                adapter.Fill(table);
                return table;

            }
        }

        public DataTable Listar(int idEmpresa)
        {
            using (SqlConnection connection = new SqlConnection(SqlConn()))
            {
                string queryString = "SELECT * FROM [dbo].[Funcionarios] WHERE [IdEmpresa] ="+ idEmpresa;
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();

                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;

                DataTable table = new DataTable();
                adapter.Fill(table);
                return table;

            }
        }

        public void DeletarFuncionario(int idFuncionario)
        {
            using (SqlConnection connection = new SqlConnection(SqlConn()))
            {
                string queryString = "DELETE FROM [dbo].[Funcionarios] WHERE [IdFuncionario] =" + idFuncionario;
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
